package datamining.clustering.kMedoid;

import java.util.ArrayList;
import datamining.clustering.test.*;

public class KMedoid {

	public static ArrayList<KMedoidCluster> KMedoidPartition(int k, ArrayList<Iris> data)
	{
		return null;
		
	}
	
}
