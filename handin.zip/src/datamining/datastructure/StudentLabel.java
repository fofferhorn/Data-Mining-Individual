package datamining.datastructure;

public enum StudentLabel {
    ac,
    dt,
    games,
    dim,
    se,
    swu,
    guest
}
