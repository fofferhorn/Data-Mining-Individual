package datamining.classification.knn.enums;

public enum Cap_Surface {
	fibrous,
	grooves,
	scaly,
	smooth,
}
