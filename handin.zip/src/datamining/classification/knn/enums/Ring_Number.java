package datamining.classification.knn.enums;

public enum Ring_Number {
none,
one,
two, 
}
