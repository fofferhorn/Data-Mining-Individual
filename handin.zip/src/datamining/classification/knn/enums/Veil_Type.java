package datamining.classification.knn.enums;

public enum Veil_Type {
partial, 
universal,
}
