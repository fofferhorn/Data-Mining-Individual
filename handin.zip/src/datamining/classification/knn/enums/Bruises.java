package datamining.classification.knn.enums;

public enum Bruises {
bruises,
no_bruises,
}
