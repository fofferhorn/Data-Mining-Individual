package datamining.classification.knn.enums;

public enum Stalk_Root {
	bulbous,
	club,
	cup,
	equal,
	rhizomorphs,
	rooted,
	missing,
}
