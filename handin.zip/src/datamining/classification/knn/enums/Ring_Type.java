package datamining.classification.knn.enums;

public enum Ring_Type {
	cobwebby,
	evanescent,
	flaring,
	large,
	none,
	pendant,
	sheathing,
	zone,
}
