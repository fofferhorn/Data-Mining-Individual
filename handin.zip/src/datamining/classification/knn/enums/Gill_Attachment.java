package datamining.classification.knn.enums;

public enum Gill_Attachment {
	attached,
	descending,
	free,
	notched,
}
