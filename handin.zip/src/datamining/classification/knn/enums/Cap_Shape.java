package datamining.classification.knn.enums;

public enum Cap_Shape {
	bell,
	conical,
	convex,
	flat,
	knobbed,
	sunken,
}
