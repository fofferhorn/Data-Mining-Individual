package datamining.classification.knn.enums;

public enum Population {
	abundant,
	clustered,
	numerous,
	scattered,
	several,
	solitary,
}
