package datamining.classification.knn.enums;

public enum Stalk_Shape {
	enlarging,
	tapering,
}
