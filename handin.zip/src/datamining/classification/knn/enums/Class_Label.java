package datamining.classification.knn.enums;

public enum Class_Label {
	edible,
	poisonous,
 }
