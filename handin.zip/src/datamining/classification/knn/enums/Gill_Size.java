package datamining.classification.knn.enums;

public enum Gill_Size {
broad,
narrow,
}
